<?php
// Define all global parameters here
// Default enpoint is provided in case there is no setting in .env
define('MINIM_DEFAULT_ENDPOINT', 'https://minim-api.tourwriter.com:3030/');

// The if statements are here incase we decide to change global variables in the .env
if(!defined('MINIM_ENDPOINT')) {
  define('MINIM_ENDPOINT', MINIM_DEFAULT_ENDPOINT);
}

// Define parameters for Minim API
if(!defined('MINIM_REQUEST_PARAMS')) {
  define('MINIM_REQUEST_PARAMS', '?$eager=[heros,items.[bookable_items.[assets,addons.[option.[product.[supplier]]]],non_bookable_items.[assets]]]');
}

// Define item image sizes
if (!defined('MINIM_IMAGE_SQUARE')) define('MINIM_IMAGE_SQUARE', '690x690');
if (!defined('MINIM_IMAGE_STANDARD')) define('MINIM_IMAGE_STANDARD', '800x434');
if (!defined('MINIM_IMAGE_THUMBNAIL')) define('MINIM_IMAGE_THUMBNAIL', '170x170');

// Define how different item types should show
if (!defined('MINIM_ITEM_TYPES_TO_HIDE')) define('MINIM_ITEM_TYPES_TO_HIDE', ['direction']);
if (!defined('MINIM_SKINNY_TYPES')) define('MINIM_SKINNY_TYPES', ['guide', 'transfer']);

// Define where in the post or page the itinerary should be displayed
if(!defined('MINIM_ITINERARY_DISPLAY_OPTIONS')) {
  define('MINIM_ITINERARY_DISPLAY_OPTIONS', ['above', 'below', 'hide']);
}
if(!defined('MINIM_ITINERARY_DEFAULT_DISPLAY_OPTION')) {
  define('MINIM_ITINERARY_DEFAULT_DISPLAY_OPTION', 'below');
}

// Register admin styles and scripts
add_action('admin_enqueue_scripts', 'minim_enqueue_admin_scripts');

// Register plugin options
add_action('admin_init', 'minim_admin_init');

// Add a link to the settings page into the settings submenu.
add_action('admin_menu', 'minim_options_page'); 

// Add settings link to Plugins page
add_filter('plugin_action_links_' . MINIM_PLUGIN_FILE, 'minim_plugin_action_links');

// Append or prepend itinerary to content of post or page
add_filter('the_content', 'minim_append_itinerary');

function minim_enqueue_admin_scripts() {
  wp_enqueue_script( 'minim-styles', plugin_dir_url(__FILE__) . 'dist/js/minim-by-tourwriter-admin.js');
  wp_enqueue_style( 'minim-admin-styles', plugin_dir_url(__FILE__) . 'dist/css/minim-by-tourwriter-admin.css');

}
