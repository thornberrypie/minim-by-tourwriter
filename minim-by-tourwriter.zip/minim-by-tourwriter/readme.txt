=== Minim by Tourwriter ===

Contributors: tourwriter
Plugin Name: Minim by Tourwriter
Plugin URI: https://websitebuilder.tourwriter.com
Tags: travel, itinerary, tours, software, tour operator, dmc, tourwriter, minim
Requires at least: 4.4
Tested up to: 5.3
Requires PHP: 5.2
Stable tag: 1.0
Version: 1.0

== Description ==

= Easily display your Minim itineraries on your website =

Integrates Minim tour operator software with Wordpress by allowing itineraries created in Minim to be embedded in your Wordpress posts and pages.

Displaying Minim itineraries on your website is now as simple as creating regular posts.

== Installation ==

= An active Minim account is required to use this plugin =

If you don't have a Minim account you can [sign up for a free trial](https://minim.tourwriter.com/free-trial?ref=plugin).

Once the plugin is installed and activated go to **Settings->Minim by Tourwriter** and follow the instructions to add your **Minim Classic Key** which can be found on the profile page in Minim. This acts as an API key to allow your website to access itineraries on your Minim account.

Now when you navigate to a post or page in your Wordpress admin you should see a new **Minim by Tourwriter** tab in the right hand sidebar of the edit screen. Obtain from Minim the ID of the itinerary you want to display and paste it into the Itinerary ID field.

Once your changes are saved you should be able to visit the page and see your Minim Itinerary embedded as part of the page content.

== Links ==

Here's a sample website that uses **Minim by Tourwriter** to display itineraries: [https://asgard.tourwriter.com](https://asgard.tourwriter.com/?ref=plugin)

== Screenshots ==

1. The plugin in action with the [Minim Website Builder](https://websitebuilder.tourwriter.com/?ref=plugin)

== Frequently Asked Questions ==

= What is Minim? =

[Minim](https://itinerarybuilder.tourwriter.com/?ref=plugin) is an online itinerary builder built by [Tourwriter](https://www.tourwriter.com/?ref=plugin) designed to help tour operators thrive by saving huge amounts of time in their daily business.

= How do I show Minim itineraries on my website? =

See installation instructions in the section above.

= Where do I find the ID of an itinerary in Minim? =

The ID is a string of characters found in the URL (address bar) when you visit your itinerary in Minim. It's the section of the URL after itineraries/ and before the next forward slash.

= What is supposed to happen when I click the **Check API Key** button in the plugin settings?

It should give you a verification message that the key you have entered is valid, or an error message if the key is not valid.

If you don't see any message at all it does not mean that the rest of the plugin's features are not working, so you can proceed with setup instructions in this case as long as you know your **Minim Classic Key** is correct.

When you first enter your **Minim Classic Key**, clicking the **Check API Key** button only validates the key, but does not save it. You still need to click the **Save Settings** button before you can start using the plugin.

= Why doesn't the Itinerary ID field appear on the edit screen of my post? =

* The **Minim by Tourwriter** tab containing the Itinerary ID field will appear on regular Wordpress posts and pages only. If you're using Custom Post Types it won't appear unless the name of the post type is Itinerary.

* Check that you have saved your **Minim Classic Key** in **Settings->Minim by Tourwriter**.

* These fields may not appear if you're using a version of Wordpress older than what is required.