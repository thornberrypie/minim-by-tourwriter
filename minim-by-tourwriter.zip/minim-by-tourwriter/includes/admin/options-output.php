<?php
require_once plugin_dir_path(__FILE__) . './options.php';
/**
 * This function emits the HTML for the options page.
 */
function minim_options_page_html() {
  // Don't proceed if the user lacks permissions.
  if (!current_user_can('manage_options')) {
    return;
  }
  $options = minim_get_options();
  ?>
  <div class="wrap">
    <h1><?= esc_html(get_admin_page_title()); ?></h1>
    <form action="options.php" method="post">
      <?php settings_fields('minim_options_group'); ?>
      <h2> 
        <?php esc_html_e('Authentication', MINIM_TEXT_DOMAIN); ?>
      </h2>
      <p>
        <?php esc_html_e('Enter your Minim API Key (Classic Key) in the box below then click the "Check API Key" button to connect your Minim account.', MINIM_TEXT_DOMAIN); ?>
      </p>
      <p>
        <?php esc_html_e('Once verified, click the "Save Settings" button and you can begin embedding itineraries into your posts and pages!', MINIM_TEXT_DOMAIN); ?>
      </p>
      <table class="form-table">
        <tr>
          <th scope="row">
            <label for="minim_options[minim_key]">
              <?php esc_html_e('Minim Classic Key', MINIM_TEXT_DOMAIN); ?>:
            </label>
          </th>
          <td>
            <input
              class="regular-text"
              id="minim-key"
              name="minim_options[minim_key]"
              type="text"
              value="<?php echo esc_attr($options['minim_key']); ?>"
            />
             <p>
             <?php esc_html_e('This is the value of the "Classic key" field in the "My profile" area of your Minim account.', MINIM_TEXT_DOMAIN); ?>
            </p>
            <div id="minim-info" class="minim-info">
              <div class="minim-info-icon"></div>
              <div id="minim-success-message" class="minim-message minim-message--success">
              <?php esc_html_e('Success! API key verified.', MINIM_TEXT_DOMAIN); ?>
              </div>
              <div id="minim-error-message" class="minim-message minim-message--error">
              <?php esc_html_e('Your Minim Classic Key appears to be incorrect', MINIM_TEXT_DOMAIN); ?>
              </div>
            </div>

            <button id="minim-validate-button" class="minim-validate-button">Check API Key</button>
          </td>
        </tr>
 
      </table>
      <hr>
      <div style="display:none">
      <h2>Layout</h2>
      <p>
        <?php esc_html_e("Images coming from Minim can be set to one of the sizes specified below. Please choose something appropriate to your layout.", MINIM_TEXT_DOMAIN) ?>     </p>
      <table class="form-table">
        <tr>
          <th scope="row">
            <label for="minim_options[minim_image_size]">
              <?php esc_html_e('Image size', MINIM_TEXT_DOMAIN); ?>:
            </label>
          </th>

          <td>
            <select id="minim_options[minim_image_size]" name="minim_options[minim_image_size]">
              <option 
                value="large" 
                <?php selected( $options["minim_image_size"], "large" ); ?>
              >
                Large (1170x658)
              </option>
              <option
                value="square"
                <?php selected( $options["minim_image_size"], "square" ); ?>
              >
                Square (600x600)
              </option>
              <option
                value="thumbnail"
                <?php selected( $options["minim_image_size"], "thumbnail" ); ?>
              >
                Thumbnail (340x200)
              </option>
            </select>

            <p class="description">
              <?php esc_html_e('Itinerary images will appear at this size on your post or page', MINIM_TEXT_DOMAIN); ?>
            </p>
          </td>
        </tr>

      </table>
      </div>
      <?php submit_button(__('Save Settings', MINIM_TEXT_DOMAIN));?>
 
    </form>
  </div>
  <?php
}