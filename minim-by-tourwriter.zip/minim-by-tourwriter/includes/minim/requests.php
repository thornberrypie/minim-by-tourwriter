<?php
/*
* $url (string) endpoint to fetch data from
* $headers (array) headers to send with request
*/
function minim_fetch_data( $url, $headers ) {
  $response = wp_remote_get( $url, ['body' => $headers] );

  if ( is_wp_error( $response ) ) {
    $error_message = $response->get_error_message();
    return "Something went wrong with the GET request: $error_message";
  } else {
    return $response['body'];
  }
}

function minim_get_access_token() {
  $url = MINIM_ENDPOINT.'authentication';
  $data = [
    'classic_key' => MINIM_API_KEY,
    'strategy' => 'classic'
  ];

  $response = wp_remote_post( $url, ['body' => $data] );

  if ( is_wp_error( $response ) ) {
    $error_message = $response->get_error_message();
    if( WP_DEBUG ) {
      echo "Something went wrong with the POST request: $error_message";
    }
    return '';
  } else {
    return json_decode( $response['body'], true );
  }
}

function minim_get_request_headers() {
  $tokenResult = minim_get_access_token();

  if( !array_key_exists( 'accessToken', $tokenResult ) ){
    if( WP_DEBUG ) {
      var_dump( $tokenResult );
    }
    return false;
  }

  return [
    'Authorization' => $tokenResult["accessToken"],
    'Accept' => 'application/json',
    'Content-Type' => 'application/json',
    'X-Minim-Source' => 'wordpressplugin'
  ];
}

/*
* $id (string) Minim itinerary ID
*/
function minim_get_itinerary_data( $id ) {
  $url = MINIM_ENDPOINT.'itineraries/'.$id.MINIM_REQUEST_PARAMS;

  $headers = minim_get_request_headers();
  if( !$headers ) return false;

  $response = wp_remote_get( $url, ['headers' => $headers] );

  if ( is_wp_error( $response ) ) {
    if( WP_DEBUG ) {
      $error_message = $response->get_error_message();
      echo "Something went wrong with the GET request: $error_message";
      var_dump( $response );
    }
    return false;
  } else {
    return json_decode( $response['body'], true );
  }
}

function minim_get_itineraries_data( $limit=100 ) {
  $url = MINIM_ENDPOINT.'itineraries'.MINIM_REQUEST_PARAMS.'&$limit='.$limit;

  $headers = minim_get_request_headers();
  if( !$headers ) return false;

  return minim_fetch_data( $url, $headers );
}

function minim_get_itineraries_content( $postsPerPage=100 ) {
  $posts = get_posts( ['posts_per_page' => $postsPerPage, 'post_type' => 'itinerary'] );
  $itineraries = minim_get_itineraries_data();

  if( !$itineraries ) {
    return '<p class="minim-error">ERROR: unable to retrieve itineraries from Minim</p>';
  }

  // Return error message is no data was returned from Minim
  if( !array_key_exists( 'data', $itineraries ) ) {
    return '<p class="minim-error">ERROR: No itineraries were found.</p>';
  }

  // Return error message if the access token is incorrect
  if( array_key_exists( 'name', $itineraries['data'] ) ) {
    if( $itineraries['data']['name'] == 'JsonWebTokenError' ) {
      return '<p class="minim-error">ERROR: There was a problem generating an access token for the Minim API request</p>';
    }
  }

  $html = '';

  foreach( $posts as $post ){
    $itin_ID = get_post_meta( $post->ID, 'itinerary_id' );
    $html .= '<div class="minim-itineraries-list-item">';
    $html .= '<a href="/'.$post->post_name.'"><h2>'.$post->post_title.'</h2></a>';

    foreach( $itineraries['data'] as $image ){
      if( $image['id'] === $itin_ID ){
        if( empty( $image['heros'] ) ){
          $itin_img = get_post_meta( $post->ID, 'itinerary_image' );
          $html .= '<img src="'.$itin_img['sizes']['large'].'" alt="'.TW_PLACEHOLDER_IMG_URL.'">';
        } else {
          foreach( $image['heros'] as $img ){
            $html .= '<img src="'.$img['image_urls']['square'].'" alt="'.$img['image_urls']['square'].'">';
          }
        }
      } 
    }
    $html .= '</div>';
  }

  return $html;
}