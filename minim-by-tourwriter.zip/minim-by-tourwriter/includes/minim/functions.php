<?php
function minim_compare_itinerary_start_date( $a, $b ) {
  $date = 'start_date';
  $time = 'start_time';

  // Decide order of items that are in the same day
  if ( $a[$date] == $b[$date] ) {

    // Sort by order field if it is set
    if( $a['orders'] || $b['orders'] ) {

      // Always set item lower if it's value is 0
      if( $a['orders'][0]['order'] === 0 ) {
        return -1;
      } 
      
      return ( $a['orders'][0]['order'] < $b['orders'][0]['order'] ) ? -1 : 1;
    }

    // Sort by start time if start date is the same
    if ( $a[$time] == $b[$time] ) {
      return 0;

    } else {
      return ( $a[$time] < $b[$time] ) ? -1 : 1;
    }
  }

  return ( $a['start_date'] < $b['start_date'] ) ? -1 : 1;
}

// Each itinerary contains assets, bookable_items and non_bookable_items
function minim_get_itinerary_items( $itinerary ) {
  $items = [];

  // Build array of bookable and non-bookable items
  foreach( $itinerary['items'] as $i ) {
    $b_items = $i['bookable_items'];
    $nb_items = $i['non_bookable_items'];

    // Add non_bookable items
    if( is_array( $nb_items ) && !empty( $nb_items ) ) {
      $item = $nb_items[0];

      // Change 'date' to 'start_date' to match bookable items data structure
      if( !array_key_exists( 'start_date', $item ) && isset( $item['date'] ) ) {
        $item['start_date'] = $item['date'];
        unset( $item['date'] );
        array_push( $items, $item );
      }
    }

    // Add bookable items
    if( is_array( $b_items ) && !empty( $b_items ) ) {

      if( $b_items[0]['type'] !== 'fee' ) {
        array_push( $items, $b_items[0] );
      }
      
    }
  }

  // Sort items by start date / time
  usort( $items, 'minim_compare_itinerary_start_date' );

  return $items;
}

function minim_get_itinerary_item_image( $item ) {
  $imgSize = minim_get_itinerary_item_image_size( $item );
  $imgClass = minim_get_itinerary_item_image_class( $imgSize );

  if( is_array( $item['assets'] ) && !empty( $item['assets'] ) ) {
    $assets = $item['assets'][0];
    $image = $assets['image_urls'];
    $item_name = isset( $item['name'] ) ? esc_html( $item['name'] ) : '';

    if( isset( $image ) && !empty( $image ) ) {
      if( isset( $image['thumbnail'] ) ) {
        $thumb = esc_html( $image['thumbnail'] );
        $src = str_replace( 'thumbnail', '/'.$imgSize.'/assets/', $thumb );

        return '<figure class="wp-block-image minim-itinerary-item-image'.$imgClass.'"><img src="'.$src.'" alt="'.$item_name.'"></figure>';
      }
    }
  }

  return '';
}

function minim_get_itinerary_item_image_class( $size ) {
  switch( $size ) {
    case MINIM_IMAGE_THUMBNAIL:
      return ' minim-itinerary-item-image--thumb';
    break;
    case MINIM_IMAGE_SQUARE:
      return ' minim-itinerary-item-image--square';
    break;
    default:
      return '';
  }
}

function minim_get_itinerary_item_image_size( $item ) {
  $size = MINIM_IMAGE_STANDARD;
  $infoLength = strlen( $item['name'] ) * 3 + strlen( $item['description'] );

  // Use square image if info size is quite long
  if( $infoLength > 500 ) {
    $size = MINIM_IMAGE_SQUARE;
  }

  // Use thumbnail if item should show as "skinny"
  if( in_array( $item['type'], MINIM_SKINNY_TYPES ) ) {
    $size = MINIM_IMAGE_THUMBNAIL;
  }

  return $size;
}

function minim_get_item_addons( $item ) {
  $item_addons = isset( $item['addons'] ) ? $item['addons'] : '';
  $addons = '';

  if( !empty( $item_addons ) ) {
    foreach( $item_addons as $addon ) {
      if( isset( $addon['name'] ) && $addon['name'] !== '' ) {
        $addons .= '<li>'.$addon['name'].'</li>';
      }
    }
  }

  return $addons !== '' ? '<ul class="minim-itinerary-item-addons">'.$addons.'</ul>' : '';
}

// Calculate how many days or night a multi-day item spans
function minim_get_day_difference( $date1, $date2 ) {
  $dif = strtotime( $date2 ) - strtotime( $date1 );

  return round( $dif / ( 60 * 60 * 24 ) );
}

// Format title based on duration of item
function minim_get_item_title( $item ) {
  $title = '';
  $start = $item['start_date'];
  $end = $item['end_date'];

  if( isset( $item['name'] ) ) {
    $title = '<h2 class="minim-itinerary-item-title">'.$item['name'];

    if( isset( $end ) && $start !== $end ) {
      $numDays = minim_get_day_difference( $start, $end );

      if( $item['type'] === 'accommodation' ) {
        $title .= ( $numDays > 1 ) ? ' ('.$numDays.'&nbsp;nights)' : ' ('.$numDays.'&nbsp;night)';
      } else {
        $title .= ( $numDays > 1 ) ? ' ('.$numDays.'&nbsp;days)' : ' ('.$numDays.'&nbsp;day)';
      }
    }
    $title .= '</h2>';
  }

  return $title;
}

function minim_format_itinerary_items( $items ) {
  $html = '';
  $day = 0;

  // Assume that the first item in an itinerary appears on the first day
  $itineraryStartDate = $items[0]['start_date'];

  // Loop through items building the html for the itinerary
  foreach ( $items as $item ) {
    $item_description = isset( $item['description'] ) ? $item['description'] : '';
    $item_name = isset( $item['name'] ) ? esc_html( $item['name'] ) : '';
    $item_start_date = isset( $item['start_date'] ) ? esc_html( $item['start_date'] ) : '';
    $item_type = isset( $item['type'] ) ? esc_html( $item['type'] ) : '';

    // Use square image if info size is quite long
    $infoLength = strlen( $item_name ) * 3 + strlen( $item_description );
    $squareImg = ( $infoLength > 500 ) ? true : false;
    $image = minim_get_itinerary_item_image( $item, $squareImg );
    $itemClass = 'minim-itinerary-item--'.str_replace( ' ', '-', $item_type );

    // Show day number if it's different from the last
    $daysPassed = minim_get_day_difference( $itineraryStartDate, $item_start_date ) + 1;
    
    if( $daysPassed !== $day ){
      $day = $daysPassed;
      $html .= '<h3 class="minim-itinerary-day"><span>Day '.$day.'</span></h3>';
    }

    // Add a CSS class for skinny items
    if( in_array( $item_type, MINIM_SKINNY_TYPES ) ) {
      $itemClass .= ' minim-itinerary-item--skinny';
    }

    // Only output the item types we want to show
    if( !in_array( $item_type, MINIM_ITEM_TYPES_TO_HIDE ) ) {
      $html .= '<div class="minim-itinerary-item '.$itemClass.'">';
      $html .= $image;
      $html .= '<div class="minim-itinerary-item-info">';
      $html .= minim_get_item_title( $item );
      $html .= ( $item_description !== '' ) ? '<p>'.$item_description.'</p>' : '';
      $html .= minim_get_item_addons( $item );
      $html .= '</div>'; // end .minim-itinerary-item-info
      $html .= '</div>'; // end .minim-itinerary-item
    }
  }

  return '<div class="minim-itinerary">'.$html.'</div>';
}

// Append Minim itinerary to the_content
function minim_append_itinerary( $content ) {
  // Prevent itinerary from appearing in post lists
  if( !is_single() && !is_page() ) {
    return $content;
  }

  $post_ID = get_the_ID();
  $itinerary_ID = get_post_meta( $post_ID, 'itinerary_id', true );
  $itinerary_display = get_post_meta( $post_ID, 'itinerary_display', true );
  $minim_API = minim_get_options();
  $itineraryContent = '';

  if( $itinerary_ID && $minim_API['minim_key'] !== '' ){
    $itinerary = minim_get_itinerary_data( $itinerary_ID );
    if ( isset( $itinerary['items'] ) ){

      // If the itinerary has at least one item
      if( sizeof( $itinerary['items'] ) > 0 ) {
        $itinerary_array = minim_get_itinerary_items( $itinerary );
        $itineraryContent = minim_format_itinerary_items( $itinerary_array );
      } else {

      // If the itinerary exists but has no items
        if( current_user_can( 'edit_post', $post_ID ) ) {
          $itineraryContent = '<p class="notice">'. __( 'This itinerary does not seem to contain any viewable items. Please update the itinerary in Minim to view the items here.', MINIM_TEXT_DOMAIN ).'</p>';
        }
      }
    } else {
      
      // If the itinerary can't be found
      if( current_user_can( 'edit_post', $post_ID ) ) {
        $error = minim_render_error();

        if( is_wp_error( $error ) ) {
          $itineraryContent = '<p class="error notice">'.$error->get_error_message().'</p>';
        }
      }
    }
  }

  $fullcontent = $content;

  if( $itinerary_display && $itinerary_display !== 'hide' ) {
    if( $itinerary_display === 'above' ) {
      $fullcontent = $itineraryContent . $content;
    } else {
      $fullcontent = $content . $itineraryContent;
    }
  }

  return $fullcontent;
}

function minim_render_error() {
  return new WP_Error( 'itinerary', __( 'This content cannot be displayed. Please ensure that you have entered the correct Itinerary ID.', MINIM_TEXT_DOMAIN ) );
}